# ⚡ Spark AI - Instant Screen Lens & ChatGPT Snippet Solver (Chrome Extension Manifest V3)

Spark AI is a 100% self-contained Manifest V3 Chrome Extension. It operates independently without relying on external web app assets.

## 🔑 Multi-Provider Key Rotation & 100% Free Failovers
Spark AI includes built-in API key rotation and multi-provider failover to bypass rate limits completely:
- **3 Google Gemini Keys**: Configure up to 3 Gemini API keys for 45 RPM combined capacity.
- **⚡ Groq Free Key (`console.groq.com`)**: **100% FREE!** 30 Requests Per Minute & 14,400 Requests Per Day for Llama 3.3 70B!
- **🌐 OpenRouter Free Key (`openrouter.ai`)**: **100% FREE!** Free access to DeepSeek R1 Free, Llama 3.3 Free, and Gemini Flash Lite Free.
- **OpenAI Fallback**: Enter an optional OpenAI API Key (`sk-proj-...`) as an ultimate fallback.

## 📁 Extension Files Included (`/spark/`)
- `manifest.json` — Chrome Extension Manifest V3 configuration with shortcuts (`Ctrl+Shift+S` and `Ctrl+Shift+C`)
- `background.js` — Service worker featuring multi-key round-robin rotation & OpenAI failover engine
- `content.js` — High-precision DOM TreeWalker text OCR and selection overlay engine
- `styles.css` — Apple Liquid Glass styling and Cloud Thought Bubble animations
- `popup.html` & `popup.js` — Toolbar Multi-Key Cluster settings popup
- `icon16.png`, `icon32.png`, `icon48.png`, `icon128.png`, `icon.png` — Real 32-bit RGBA icons

## 🚀 How to Load Unpacked in Google Chrome
1. Download or export this project ZIP.
2. Open Google Chrome and go to `chrome://extensions/`.
3. Enable **Developer mode** in the top-right toggle switch.
4. Click **Load unpacked** in the top-left menu.
5. Select the `spark` folder directly inside your unzipped project directory.
6. Click the Spark extension icon in your Chrome toolbar, enter your Gemini and/or OpenAI API Keys, and save.
7. Highlight any question on screen with **Ctrl + Shift + S** or **Ctrl + Shift + C** to get direct AI answers!
