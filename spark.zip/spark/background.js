// Spark Chrome Extension - Background Worker (Gemini 3.6 Flash Direct AI Solver)

chrome.runtime.onInstalled.addListener(() => {
  console.log('Spark AI Extension Installed.');
});

// Listen for keyboard command (Ctrl + Shift + S)
chrome.commands.onCommand.addListener((command) => {
  if (command === 'toggle-spark') {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0] && tabs[0].id) {
        chrome.tabs.sendMessage(tabs[0].id, { action: 'START_SELECTION' }).catch((err) => {
          // If content script not injected yet, inject manually
          chrome.scripting.executeScript({
            target: { tabId: tabs[0].id },
            files: ['content.js']
          }).then(() => {
            chrome.scripting.insertCSS({
              target: { tabId: tabs[0].id },
              files: ['styles.css']
            });
            setTimeout(() => {
              chrome.tabs.sendMessage(tabs[0].id, { action: 'START_SELECTION' });
            }, 100);
          }).catch(console.error);
        });
      }
    });
  }
});

// Handle analysis requests from content script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'ANALYZE_SNIPPET') {
    handleAnalyzeSnippet(request.text).then((answer) => {
      sendResponse({ answer });
    }).catch((err) => {
      sendResponse({ answer: `⚠️ Spark AI Error: ${err.message || 'Failed to process question.'}` });
    });
    return true; // Keep channel open for async response
  }
});

let keyRotationIndex = 0;

async function handleAnalyzeSnippet(text) {
  const data = await chrome.storage.local.get([
    'geminiApiKey', 'geminiKey1', 'geminiKey2', 'geminiKey3',
    'groqKey', 'openrouterKey', 'openaiKey'
  ]);
  
  // Extract all unique non-empty Gemini keys
  const geminiKeys = Array.from(new Set([
    data.geminiKey1,
    data.geminiKey2,
    data.geminiKey3,
    data.geminiApiKey
  ].filter(k => k && typeof k === 'string' && k.trim().length > 0)));

  const groqKey = data.groqKey ? data.groqKey.trim() : '';
  const openrouterKey = data.openrouterKey ? data.openrouterKey.trim() : '';
  const openaiKey = data.openaiKey ? data.openaiKey.trim() : '';

  if (geminiKeys.length === 0 && !groqKey && !openrouterKey && !openaiKey) {
    return "⚠️ API Key Required\n\nPlease click the Spark extension icon in your browser toolbar and enter your Gemini, Groq, or OpenRouter API key to solve questions directly.";
  }

  const systemPrompt = `You are Spark AI, an expert AI question and test solver. Your job is to solve any quiz, test, conversational dialogue, reading comprehension, grammar, or math question accurately.

CRITICAL INSTRUCTIONS:
1. Read and analyze the prompt and options carefully to determine what question or dialogue is being presented.
2. Answer ONLY the specific question or prompt present in the snippet provided. Do NOT answer other questions outside the snippet.
3. If the prompt is a statement or conversational prompt (e.g. "4) I'd like two tickets for tomorrow night."), select the single best logical response from the provided options (e.g., "I'll just check for you.").
4. NEVER output the question prompt line itself as the answer just because it starts with a number like "4)". Always evaluate which choice actually answers the question!
5. Output the exact correct answer directly, cleanly, and immediately. No unnecessary preamble or commentary.`;

  const geminiModels = [
    'gemini-3.6-flash',
    'gemini-3.1-flash-lite',
    'gemini-flash-latest'
  ];

  let lastErrorMessage = '';

  // 1. Google Gemini Key Cluster (Round-Robin Rotation & Failover)
  if (geminiKeys.length > 0) {
    const rotatedKeys = [];
    for (let i = 0; i < geminiKeys.length; i++) {
      const idx = (keyRotationIndex + i) % geminiKeys.length;
      rotatedKeys.push(geminiKeys[idx]);
    }
    keyRotationIndex = (keyRotationIndex + 1) % geminiKeys.length;

    for (const apiKey of rotatedKeys) {
      for (const model of geminiModels) {
        try {
          const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;
          const res = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              contents: [{ parts: [{ text: `${systemPrompt}\n\nSnippet Content:\n${text}` }] }]
            })
          });

          const json = await res.json();

          if (res.ok && json.candidates && json.candidates[0]?.content?.parts[0]?.text) {
            return json.candidates[0].content.parts[0].text;
          }

          if (json.error) {
            lastErrorMessage = json.error.message || `Error status ${res.status}`;
            if (res.status === 429 || json.error.code === 429 || json.error.status === 'RESOURCE_EXHAUSTED') {
              console.warn(`Quota limit reached for Gemini key (${apiKey.slice(0, 6)}...), switching key/model...`);
              break;
            }
          }
        } catch (err) {
          console.warn(`Error connecting to ${model}:`, err);
          lastErrorMessage = err.message || 'Network error';
        }
      }
    }
  }

  // 2. Groq Cloud API Failover (100% Free - 30 RPM / 14,400 RPD)
  if (groqKey) {
    console.log('Executing Groq Cloud API failover...');
    const groqModels = ['llama-3.3-70b-versatile', 'llama-3.1-8b-instant'];
    for (const gModel of groqModels) {
      try {
        const res = await fetch('https://api.groq.com/openai/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${groqKey}`
          },
          body: JSON.stringify({
            model: gModel,
            messages: [
              { role: 'system', content: systemPrompt },
              { role: 'user', content: text }
            ],
            temperature: 0.1
          })
        });

        const json = await res.json();
        if (res.ok && json.choices && json.choices[0]?.message?.content) {
          return json.choices[0].message.content.trim();
        }

        if (json.error) {
          lastErrorMessage = `Groq Error: ${json.error.message || 'Rate limit'}`;
        }
      } catch (err) {
        console.warn(`Groq error for ${gModel}:`, err);
        lastErrorMessage = `Groq Network Error: ${err.message}`;
      }
    }
  }

  // 3. OpenRouter Free API Failover (100% Free Llama 3.3 / DeepSeek models)
  if (openrouterKey) {
    console.log('Executing OpenRouter Free API failover...');
    const openrouterModels = [
      'meta-llama/llama-3.3-70b-instruct:free',
      'deepseek/deepseek-r1:free',
      'google/gemini-2.0-flash-lite-001:free'
    ];
    for (const orModel of openrouterModels) {
      try {
        const res = await fetch('https://openrouter.ai/api/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${openrouterKey}`
          },
          body: JSON.stringify({
            model: orModel,
            messages: [
              { role: 'system', content: systemPrompt },
              { role: 'user', content: text }
            ],
            temperature: 0.1
          })
        });

        const json = await res.json();
        if (res.ok && json.choices && json.choices[0]?.message?.content) {
          return json.choices[0].message.content.trim();
        }

        if (json.error) {
          lastErrorMessage = `OpenRouter Error: ${json.error.message || 'Rate limit'}`;
        }
      } catch (err) {
        console.warn(`OpenRouter error for ${orModel}:`, err);
        lastErrorMessage = `OpenRouter Network Error: ${err.message}`;
      }
    }
  }

  // 4. OpenAI API Fallback (if configured)
  if (openaiKey) {
    console.log('Executing OpenAI fallback call...');
    try {
      const res = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${openaiKey}`
        },
        body: JSON.stringify({
          model: 'gpt-4o-mini',
          messages: [
            { role: 'system', content: systemPrompt },
            { role: 'user', content: text }
          ],
          temperature: 0.1
        })
      });

      const json = await res.json();
      if (res.ok && json.choices && json.choices[0]?.message?.content) {
        return json.choices[0].message.content.trim();
      }

      if (json.error) {
        lastErrorMessage = `OpenAI Error: ${json.error.message || 'Rate limit'}`;
      }
    } catch (err) {
      console.warn('OpenAI fallback error:', err);
      lastErrorMessage = `OpenAI Network Error: ${err.message}`;
    }
  }

  return `⚠️ Rate Limit Exceeded Across All Configured Keys\n\n${lastErrorMessage}\n\nTip: You can add 100% FREE Groq API keys (console.groq.com - 30 RPM / 14,400 RPD) or OpenRouter Free API keys in the Spark Extension popup to eliminate rate limit delays completely!`;
}
