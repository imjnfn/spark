// Spark Chrome Extension - Pure Vanilla JS Content Script with Apple Liquid Glass & Cloud Thought Bubble

(() => {
  if (window.__spark_injected) return;
  window.__spark_injected = true;

  let isSelecting = false;
  let startX = 0;
  let startY = 0;
  let currentSelection = null;
  let overlay = null;
  let selectionBox = null;
  let activeAssistantCard = null;
  let rafId = null;

  // Listen for messages from background worker
  chrome.runtime.onMessage.addListener((message) => {
    if (message.action === 'START_SELECTION') {
      startSelectionMode();
    }
  });

  // Global hotkeys (Ctrl+Shift+S, Ctrl+Shift+C, Cmd+Shift+S/C, Alt+S/C)
  document.addEventListener('keydown', (e) => {
    const isCmdOrCtrl = e.ctrlKey || e.metaKey;
    const key = e.key ? e.key.toLowerCase() : '';

    if ((isCmdOrCtrl && e.shiftKey && (key === 's' || key === 'c')) || (e.altKey && (key === 's' || key === 'c'))) {
      e.preventDefault();
      startSelectionMode();
    } else if (e.key === 'Escape') {
      cleanupSelectionOverlay();
      removeAssistantCard();
    }
  });

  function startSelectionMode() {
    cleanupSelectionOverlay();
    removeAssistantCard();

    isSelecting = false;

    // Create full screen overlay
    overlay = document.createElement('div');
    overlay.className = 'spark-overlay';

    // Top instruction badge
    const badge = document.createElement('div');
    badge.style.cssText = 'position:fixed; top:20px; left:50%; transform:translateX(-50%); z-index:2147483647; background:rgba(15,23,42,0.9); border:1px solid rgba(251,191,36,0.5); padding:8px 18px; border-radius:12px; color:#FEF08A; font-family:sans-serif; font-size:12px; font-weight:700; box-shadow:0 0 20px rgba(245,158,11,0.3); pointer-events:none; display:flex; align-items:center; gap:8px;';
    badge.innerHTML = `
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#F59E0B" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
        <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon>
      </svg>
      <span>Drag over any question on screen</span>
      <span style="opacity:0.5; font-weight:normal; margin-left:4px;">(ESC to cancel)</span>
    `;
    overlay.appendChild(badge);

    overlay.addEventListener('mousedown', onMouseDown);
    overlay.addEventListener('mousemove', onMouseMove);
    overlay.addEventListener('mouseup', onMouseUp);

    document.body.appendChild(overlay);
  }

  function onMouseDown(e) {
    if (e.button !== 0) return; // Only left click
    isSelecting = true;
    startX = e.clientX;
    startY = e.clientY;

    if (!selectionBox) {
      selectionBox = document.createElement('div');
      selectionBox.className = 'spark-selection-box';

      // Corner dots
      const corners = ['spark-top-left', 'spark-top-right', 'spark-bottom-left', 'spark-bottom-right'];
      corners.forEach((c) => {
        const dot = document.createElement('div');
        dot.className = `spark-corner-dot ${c}`;
        selectionBox.appendChild(dot);
      });

      // Golden Lightning Bolt Badge on selection corner
      const lightningBadge = document.createElement('div');
      lightningBadge.className = 'spark-lightning-badge';
      lightningBadge.innerHTML = `
        <svg width="18" height="18" viewBox="0 0 24 24" fill="#0F172A" stroke="#0F172A" stroke-width="1">
          <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon>
        </svg>
      `;
      selectionBox.appendChild(lightningBadge);

      overlay.appendChild(selectionBox);
    }

    selectionBox.style.left = `${startX}px`;
    selectionBox.style.top = `${startY}px`;
    selectionBox.style.width = '0px';
    selectionBox.style.height = '0px';
  }

  function onMouseMove(e) {
    if (!isSelecting) return;
    const clientX = e.clientX;
    const clientY = e.clientY;

    if (rafId) cancelAnimationFrame(rafId);
    rafId = requestAnimationFrame(() => {
      const left = Math.min(startX, clientX);
      const top = Math.min(startY, clientY);
      const width = Math.abs(clientX - startX);
      const height = Math.abs(clientY - startY);

      currentSelection = { left, top, width, height };

      if (selectionBox) {
        selectionBox.style.left = `${left}px`;
        selectionBox.style.top = `${top}px`;
        selectionBox.style.width = `${width}px`;
        selectionBox.style.height = `${height}px`;
      }
    });
  }

  function getTextInBoundingBox(box) {
    // Extract selected text if user manually highlighted text
    let selectedText = window.getSelection().toString().trim();
    if (selectedText) return selectedText;

    const vLeft = box.left;
    const vTop = box.top;
    const vRight = box.left + box.width;
    const vBottom = box.top + box.height;

    const foundTexts = [];
    const walker = document.createTreeWalker(
      document.body,
      NodeFilter.SHOW_TEXT,
      {
        acceptNode: (node) => {
          if (!node.textContent || !node.textContent.trim()) return NodeFilter.FILTER_REJECT;
          const parent = node.parentElement;
          if (!parent) return NodeFilter.FILTER_REJECT;
          if (parent.closest('.spark-overlay') || parent.closest('.spark-card-container')) {
            return NodeFilter.FILTER_REJECT;
          }
          const range = document.createRange();
          range.selectNodeContents(node);
          const rect = range.getBoundingClientRect();
          if (
            rect.left < vRight &&
            rect.right > vLeft &&
            rect.top < vBottom &&
            rect.bottom > vTop
          ) {
            return NodeFilter.FILTER_ACCEPT;
          }
          return NodeFilter.FILTER_REJECT;
        }
      }
    );

    while (walker.nextNode()) {
      const txt = walker.currentNode.textContent.trim();
      if (txt) {
        foundTexts.push(txt);
      }
    }

    return Array.from(new Set(foundTexts)).join(' ');
  }

  function onMouseUp(e) {
    if (!isSelecting) return;
    isSelecting = false;

    if (currentSelection && currentSelection.width > 15 && currentSelection.height > 10) {
      const extractedText = getTextInBoundingBox(currentSelection);
      const area = { ...currentSelection, text: extractedText };

      cleanupSelectionOverlay();
      showThinkingCloudAndAnalyze(area);
    } else {
      cleanupSelectionOverlay();
    }
  }

  function cleanupSelectionOverlay() {
    if (rafId) cancelAnimationFrame(rafId);
    if (overlay && overlay.parentNode) {
      overlay.parentNode.removeChild(overlay);
    }
    overlay = null;
    selectionBox = null;
    currentSelection = null;
  }

  function showThinkingCloudAndAnalyze(area) {
    removeAssistantCard();

    const container = document.createElement('div');
    container.className = 'spark-card-container';
    container.style.left = `${Math.min(area.left + area.width + 10, window.innerWidth - 440)}px`;
    container.style.top = `${Math.max(20, Math.min(area.top, window.innerHeight - 300))}px`;

    // Step 4: Apple Liquid Glass Cloud Thought Bubble with 3 thought tail circles
    const wrapper = document.createElement('div');
    wrapper.className = 'spark-thinking-wrapper';

    wrapper.innerHTML = `
      <div class="spark-floating-badge" title="Spark AI Solver">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="#0F172A" stroke="#0F172A">
          <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon>
        </svg>
      </div>

      <div class="spark-thought-trail">
        <div class="spark-thought-puff puff-sm"></div>
        <div class="spark-thought-puff puff-md"></div>
      </div>

      <div class="spark-thinking-bubble spark-cloud-shape">
        <span style="color:#FEF08A; font-weight:700; font-size:12px; letter-spacing:0.3px;">Analyzing snippet...</span>
      </div>
    `;

    container.appendChild(wrapper);
    document.body.appendChild(container);
    activeAssistantCard = container;

    // Send request to background script with strictly extracted snippet text
    const textToAnalyze = area.text ? area.text.trim() : "No text found inside the selected rectangle.";

    try {
      if (!chrome.runtime || !chrome.runtime.id) {
        throw new Error("Extension context invalidated");
      }

      chrome.runtime.sendMessage({ action: 'ANALYZE_SNIPPET', text: textToAnalyze }, (response) => {
        if (chrome.runtime.lastError) {
          renderAnswerCard(container, "⚠️ Spark Extension Context Invalidated.\n\nPlease refresh this browser page (F5 / Cmd+R) to reconnect to the updated Spark Chrome Extension.");
          return;
        }

        const answerText = response?.answer || "⚠️ No answer received. Check your API key in the extension popup.";
        
        // Step 5: Burst animation on cloud bubble
        const cloudBubble = wrapper.querySelector('.spark-thinking-bubble');
        if (cloudBubble) {
          cloudBubble.classList.add('spark-cloud-burst');
        }

        setTimeout(() => {
          renderAnswerCard(container, answerText);
        }, 250);
      });
    } catch (err) {
      renderAnswerCard(container, "⚠️ Spark Extension Context Invalidated.\n\nPlease refresh this browser page (F5 / Cmd+R) to reconnect to the updated Spark Chrome Extension.");
    }
  }

  function renderAnswerCard(container, fullText) {
    container.innerHTML = '';

    const card = document.createElement('div');
    card.className = 'spark-glass-card';

    card.innerHTML = `
      <div class="spark-card-header">
        <div class="spark-card-title">
          <div class="spark-mini-badge">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="#0F172A" stroke="#0F172A">
              <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon>
            </svg>
          </div>
          <span>Spark AI Direct Answer</span>
        </div>
        <button class="spark-card-close" title="Close (ESC)">✕</button>
      </div>

      <div class="spark-card-body">
        <span class="spark-text-content"></span><span class="spark-cursor"></span>
      </div>

      <div class="spark-card-footer">
        <span style="color:#10B981; font-weight:600; display:flex; align-items:center; gap:4px;">
          <span style="width:6px; height:6px; background:#10B981; border-radius:50%;"></span>
          Gemini 3.6 Flash
        </span>
        <button class="spark-copy-btn">Copy Answer</button>
      </div>
    `;

    container.appendChild(card);

    // Close button event
    card.querySelector('.spark-card-close').addEventListener('click', () => {
      removeAssistantCard();
    });

    // Copy button event
    const copyBtn = card.querySelector('.spark-copy-btn');
    copyBtn.addEventListener('click', () => {
      navigator.clipboard.writeText(fullText);
      copyBtn.innerText = 'Copied!';
      copyBtn.style.background = 'rgba(16, 185, 129, 0.3)';
      copyBtn.style.color = '#34D399';
      setTimeout(() => {
        copyBtn.innerText = 'Copy Answer';
        copyBtn.style.background = '';
        copyBtn.style.color = '';
      }, 1500);
    });

    // Typewriter effect
    const textEl = card.querySelector('.spark-text-content');
    const cursorEl = card.querySelector('.spark-cursor');
    let idx = 0;

    function typeChar() {
      if (idx < fullText.length) {
        textEl.textContent += fullText.charAt(idx);
        idx++;
        setTimeout(typeChar, 12);
      } else {
        if (cursorEl) cursorEl.style.display = 'none';
      }
    }

    typeChar();
  }

  function removeAssistantCard() {
    if (activeAssistantCard && activeAssistantCard.parentNode) {
      activeAssistantCard.parentNode.removeChild(activeAssistantCard);
    }
    activeAssistantCard = null;
  }
})();
