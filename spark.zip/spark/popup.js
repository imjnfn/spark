document.addEventListener('DOMContentLoaded', () => {
  const geminiKey1 = document.getElementById('geminiKey1');
  const geminiKey2 = document.getElementById('geminiKey2');
  const geminiKey3 = document.getElementById('geminiKey3');
  const groqKey = document.getElementById('groqKey');
  const openrouterKey = document.getElementById('openrouterKey');
  const openaiKey = document.getElementById('openaiKey');
  const saveKeyBtn = document.getElementById('saveKeyBtn');
  const triggerBtn = document.getElementById('triggerBtn');
  const statusMsg = document.getElementById('statusMsg');

  // Load saved API keys
  chrome.storage.local.get(['geminiApiKey', 'geminiKey1', 'geminiKey2', 'geminiKey3', 'groqKey', 'openrouterKey', 'openaiKey'], (data) => {
    if (data.geminiKey1) geminiKey1.value = data.geminiKey1;
    else if (data.geminiApiKey) geminiKey1.value = data.geminiApiKey;

    if (data.geminiKey2) geminiKey2.value = data.geminiKey2;
    if (data.geminiKey3) geminiKey3.value = data.geminiKey3;
    if (data.groqKey) groqKey.value = data.groqKey;
    if (data.openrouterKey) openrouterKey.value = data.openrouterKey;
    if (data.openaiKey) openaiKey.value = data.openaiKey;
  });

  // Save API keys
  saveKeyBtn.addEventListener('click', () => {
    const k1 = geminiKey1.value.trim();
    const k2 = geminiKey2.value.trim();
    const k3 = geminiKey3.value.trim();
    const gk = groqKey.value.trim();
    const ork = openrouterKey.value.trim();
    const oak = openaiKey.value.trim();

    chrome.storage.local.set({
      geminiApiKey: k1,
      geminiKey1: k1,
      geminiKey2: k2,
      geminiKey3: k3,
      groqKey: gk,
      openrouterKey: ork,
      openaiKey: oak
    }, () => {
      statusMsg.style.display = 'block';
      setTimeout(() => {
        statusMsg.style.display = 'none';
      }, 2000);
    });
  });

  // Trigger selection mode on current active tab
  triggerBtn.addEventListener('click', () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0] && tabs[0].id) {
        chrome.tabs.sendMessage(tabs[0].id, { action: 'START_SELECTION' }).catch(() => {
          chrome.scripting.executeScript({
            target: { tabId: tabs[0].id },
            files: ['content.js']
          }).then(() => {
            chrome.scripting.insertCSS({
              target: { tabId: tabs[0].id },
              files: ['styles.css']
            });
            setTimeout(() => {
              chrome.tabs.sendMessage(tabs[0].id, { action: 'START_SELECTION' });
            }, 100);
          });
        });
        window.close(); // Close extension popup
      }
    });
  });
});
